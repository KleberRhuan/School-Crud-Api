/* (C)2025 Kleber Rhuan */
package com.kleberrhuan.houer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HouerApplicationTests {

  @Test
  void contextLoads() {}
}
