CREATE EXTENSION IF NOT EXISTS unaccent;     
CREATE EXTENSION IF NOT EXISTS citext;      
CREATE EXTENSION IF NOT EXISTS pg_trgm;  
CREATE EXTENSION IF NOT EXISTS pgcrypto;

/* ============== SCHEMA ===================================================== */
CREATE SCHEMA IF NOT EXISTS account;

/* ============== USERS ====================================================== */
CREATE TABLE account.users (
                               id            BIGSERIAL PRIMARY KEY,
                               name          VARCHAR(120) NOT NULL,
                               email         CITEXT       NOT NULL,
                               password_hash VARCHAR(255) NOT NULL,
                               enabled       BOOLEAN      NOT NULL DEFAULT FALSE,

                               deleted       BOOLEAN      NOT NULL DEFAULT FALSE,
                               deleted_at    TIMESTAMPTZ,

                               created_at    TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
                               updated_at    TIMESTAMPTZ,
                               created_by    BIGINT,
                               updated_by    BIGINT,

                               CONSTRAINT chk_users_email_format
                                   CHECK ( email ~* '^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}$' ),
                               CONSTRAINT uk_users_email UNIQUE (email)
);

ALTER TABLE account.users
    ADD CONSTRAINT fk_users_created_by
        FOREIGN KEY (created_by) REFERENCES account.users(id)
            ON DELETE SET NULL;

ALTER TABLE account.users
    ADD CONSTRAINT fk_users_updated_by
        FOREIGN KEY (updated_by) REFERENCES account.users(id)
            ON DELETE SET NULL;

CREATE INDEX idx_users_name_unaccent_ci
    ON account.users
        USING gin (unaccent(lower(name)) gin_trgm_ops);

/* ============== USER_ROLES ================================================= */
CREATE TABLE account.user_roles (
                                    user_id BIGINT      NOT NULL,
                                    role    VARCHAR(50) NOT NULL,
                                    PRIMARY KEY (user_id, role),
                                    CONSTRAINT fk_user_roles_user
                                        FOREIGN KEY (user_id) REFERENCES account.users(id)
                                            ON DELETE CASCADE
);

CREATE INDEX idx_user_roles_role ON account.user_roles(role);

/* ============== Verification Tokens ================================================= */

CREATE TABLE IF NOT EXISTS account.verification_tokens (
                                                           token       UUID PRIMARY KEY,
                                                           user_id     BIGINT  NOT NULL,
                                                           expires_at  TIMESTAMPTZ NOT NULL,
                                                           used        BOOLEAN      DEFAULT false,
                                                           CONSTRAINT fk_vt_user FOREIGN KEY (user_id)
                                                               REFERENCES account.users(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_vt_user_used
    ON account.verification_tokens (user_id, used);