/* (C)2025 Kleber Rhuan */
package com.kleberrhuan.houer.common.domain.model.notification;

public enum Channel {
  EMAIL,
  SMS,
  PUSH,
}
