/* (C)2025 Kleber Rhuan */
package com.kleberrhuan.houer.auth.domain.model;

import lombok.Getter;

@Getter
public enum Role {
  ADMIN("ADMIN"),
  USER("USER");

  private final String name;

  Role(String name) {
    this.name = name;
  }
}
