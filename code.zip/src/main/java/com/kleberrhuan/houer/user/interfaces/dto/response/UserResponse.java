/* (C)2025 Kleber Rhuan */
package com.kleberrhuan.houer.user.interfaces.dto.response;

public record UserResponse(String name, String email) {}
